# AGENTS.md

Deck Master is an Agent-operable Solution Deck Run OS. This file is the
first entrypoint for Codex, Claude Code, OpenCode, and other local coding
agents working in this repository.

## Agent First Read Order

1. `AGENTS.md` for project rules, task routing, and safety boundaries.
2. `docs/agent-task-index.md` for user-intent to command routing.
3. `docs/agent-recovery-playbook.md` for blocked-state repair decisions.
4. `src/deck_master/resources/contracts/` for runtime JSON contracts and schema truth.
5. For the RC5 content-method increment, read
   `docs/specs/content-methods-rc5/README.md`; for the integrated content WebUI,
   `docs/specs/deck-master-webui-content-methods-20261020/README.md`.
   For inherited RC4 work:
   `docs/specs/deck-master-next-iteration-20261019/06-CODEX-HANDOFF.md`,
   then its specified reading order and the assigned N1–N6 card.
   The unique candidate ledger is
   `docs/reports/rc4/iteration-20261019/execution-ledger.json`.

RC4 inherits the rebuild, Flow Quality and RC3 contracts where the current
increment does not explicitly change them. Read historical cards only for
the dependency in question; they are not a prerequisite to every task.
For historical rebuild work, use
`docs/specs/deck-master-rebuild-v1/task-cards/README.md` and its assigned card.
Recorded past test results are not current candidate evidence.

## Rebuild Baseline (v1.1)

The current Flow Quality increment follows
`docs/specs/deck-master-flow-quality-v1.1/README.md`, then its SPEC, TASKS,
ACCEPTANCE and MIGRATION. Its T1–T9 are distinct from the older rebuild cards
below. This increment authorizes retiring the listed repository skills;
the real Codex AC-17 session and actual HOME migration remain user-run checks.
RC3 now exposes `deck-master`, `deck-content`, `deck-design`, and `deck-review`.
Their sole shared editable method source is `skills/deck-master/references/`;
read the chosen Skill and its actual workorder method paths/hash.
Content sub-intents return their own complete outputs; Design remains bounded
and Review stays read-only. Changing Skill names does not create independence.

The active implementation baseline for the mainline rebuild is
`docs/specs/deck-master-rebuild-v1/` (spec pack v1.1). Rules for this effort:

- New core code lives in `src/deck_master/` (src layout). It must never import
  the old namespaces `runtime`, `workflow`, `high_density`, `preview`, or
  `build` (the old scripts tree), and must not borrow implementations through
  `sys.path` inserts. Enforced by `tests/rebuild/test_package_boundary.py`.
- Execute work one task card at a time from `task-cards/` (25 cards, 90 ACs,
  exactly one final owner per AC). Early `min` slices may ship before a card
  closes, but never omit original-image comparison, immutable originals,
  atomic writes, or cancel/late-result protection.
- Extraction sources are fixed per file in `inventory/baseline-record.md`
  (B0 `2a866cf…`, K0 `2c5a4c50…`). Migrate function by function; never merge
  or cherry-pick PR31/K0 wholesale.
- T01 froze the per-path disposition baseline in `inventory/old-files.csv`.
  No old file is deleted before T24 verifies behavior migration and reference
  zeroing. Never delete user runs, source material, third-party skills, fonts,
  or historical artifacts. Do not reset the working tree or run
  `git clean -fdx`.

## Project Truth

- Runtime contracts: `src/deck_master/resources/contracts/` (唯一活动 schema 来源;旧合同见 docs/archive/pre-rebuild/contracts/).
- Rebuilt-core CLI entrypoint (the ONLY command surface): `deck-master`
  (console entry = `deck_master.cli:main`); source checkout equivalent:
  `python -m deck_master`. The retired legacy CLI entry is not part of the new flow.
- Legacy command mapping (spec 09.6): `deck-master legacy-map`; migration
  notes: `docs/migration-to-rebuilt-core.md`.
- Editable install supports Python 3.11 and 3.12 (`requires-python
  >=3.11,<3.14`). After `python -m pip install -e ".[dev]"`, installed command
  is `deck-master`.
- Old run paths are recognised and refused by new write commands
  (`legacy_run_format`); they are never migrated or initialised in place.

Do not infer state from prose when a JSON command exists. Prefer these
machine-readable commands:

```bash
deck-master doctor --step compose   # content inputs
deck-master doctor --step render    # renderer toolchain
deck-master doctor --step export    # delivery-time checks
deck-master continue --project <dir> --json
deck-master final-readiness --project <dir> --json
deck-master view --project <dir> --json
```

## Task Routing

- New projects default to `workbench.v3` with rc3 collaboration and a real
  instruction source; no implicit production grant. Old projects require
  explicit migration before formal writes.
- New deck from material: `deck-master create --brief … --source … --out …`
  (a plain material directory is enough; no library/workspace/backend setup).
- Change task facts or materials: `deck-master inputs show --project <dir>`,
  then `inputs update --patch … --base-revision … --operation-id …`.
  Accept only `content_update` for the resulting `compose/input_revision` task.
- Continue an existing project: `deck-master continue --project <dir>`; execute
  only the returned pending Host tasks.
- Read `methods --project … --task-id … --read` and use the Task's frozen
  ordered manifest, protocol and capabilities. Claim actual execution with
  `task start --execution-ref … --supported-protocol … --capability …` before
  producing results; repeat capability flags for the actual required set.
  Copying a handoff is not a claim. Follow `basis_changed` through formal
  retirement/reissue; never add today's role defaults to an old Task.
- Adopt a Host result: `deck-master task accept --project … --task-id …
  --operation-id … --produced-against … --result result.json`.
- Review/edit/export: `deck-master view --open --project <dir>`;
  `deck-master export --project <dir> --out <dir> --purpose review|delivery`.
- Diagnose readiness: `deck-master doctor --step <step>`; renderer gaps report
  as `needs_tool` with the real reason.
- Repair blocked state: read `docs/agent-recovery-playbook.md` and follow the
  matching blocked code.

`capabilities.read_protocols` negotiates `work_context.v2` separately from
production protocols. Full bodies are the default; manifest is not ready
context, and returned/deduplicated bytes are not proof of Host reading,
method application, independent review or approval. Reads alone never raise
the project writer floor. New persistent RC4 method/policy facts require
`rc4-content.v1`; installation rollback does not lower that boundary.

## Forbidden Actions

- Do not report readiness as passing unless the current check summary says
  pass; exit code 0 and completed tasks are never professional approval.
- Do not use fixture fallback in production or benchmark mode.
- Do not write placeholder artifacts into production runs.
- Do not commit generated runs, private benchmark sources, local env files,
  tokens, caches, or raw customer material.
- Do not expose absolute local paths, private customer names, or internal
  execution commands in customer-visible artifacts.
- Do not overwrite user files unless a command explicitly supports `--force`
  and the user asked for replacement.

## Stop And Report

Stop and report when:

- `deck-master doctor --step <step>` returns `needs_tool` or a check is not
  ready and the task needs that step.
- `deck-master continue --project <dir>` returns a status you cannot satisfy
  (missing material or a user decision).
- `deck-master final-readiness --project <dir>` reports `blocked`, or
  `deck-master export --purpose delivery` refuses with unresolved dimensions.
- A contract/schema mismatch appears and no migration path is documented.
- A command would require private backend binding or customer material not
  present in the repository.

## UI And Design Work

For visual or UI changes, read `DESIGN.md` before editing. The active design is
`docs/design/webui-opendesign-20261001/`: the received OpenDesign design system,
product UI language, current prototype, and state references. Use its Deck Master
product overrides: light neutral surfaces, black primary actions, sans-serif
product typography, and factual task/candidate states. The old cold-ink Review
Desk direction is historical, not the current constraint. Runtime integration and
remaining work follow `docs/specs/deck-master-webui-v4-20260930/README.md`.
For this increment only, A means Web UI implementation and B means capability
completion; this does not rename historical Flow Quality or W01-W12 evidence.
