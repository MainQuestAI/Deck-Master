# Deck Master Development Spec Pack

本包包含 7 份连续开发 Spec，已按 Deck Master v0.9.x 到 v1.0.0 RC 的顺序组织：

1. `deck-master-v0.9.5-review-cockpit-frontend-spec.md`
   - 目标：把 v0.9 已完成的 F1/F2/F3 后端 API 收成可持续使用的 localhost Review Cockpit 前端体验。

2. `deck-master-v0.9.6-companion-tool-uat-spec.md`
   - 目标：验证 Deck Master 与 PPT Library / PPT Deck Pro Max / PPT Master 的真实交接质量，输出 UAT reports 和 real workflow smoke。

3. `deck-master-v0.9.7-benchmark-harness-spec.md`
   - 目标：建立 benchmark case / runner / report / checkpoint 机制，为 v1.0.0 RC 真实 10x readiness 验证做准备。

4. `deck-master-v0.9.9-installation-chain-hardening-spec.md`
   - 目标：固定真实用户安装链路，确保 Deck Master 安装源位于 `~/.deck-master/current`，Agent skill 目录只保留入口软链接。

5. `deck-master-v0.9.10-first-run-orchestration-enforcement-spec.md`
   - 目标：补齐首次 Setup 引导、真实 run 门禁、顶部编排器约束、人工规划回写和外部工具 handback 登记。

6. `deck-master-v0.9.11-orchestration-runtime-realignment-spec.md`
   - 目标：重对齐 Deck Master 主控运行时，统一 run mode、setup/workspace/run state、workspace-bound request、Planner guard、sourcing 回写、tool registry、production session 和 benchmark gate。

7. `deck-master-v0.9.12-skill-suite-routing-spec.md`
   - 目标：把 Deck Master 从单一 skill 升级为 Skill Suite Runtime Foundation，先完成 suite 安装、能力状态、无副作用 readiness check、companion dry-run handoff 和 import contract。
   - 当前实现入口：以 `docs/deck-master-v0.9.12-stack-spec-pack/` 下的 Stack A/B/C 文档为准；本文件保留为历史总览。

产品架构补充：

- [Astra Skill 与项目安装适配](astra-skill-adaptation/README.md)
  - 精简 suite 入口，区分新建、局部修改和诊断；支持中央 release 配合项目 `.agents/skills` 及兼容安装检查。

- `deck-master-skill-system-product-architecture.md`
  - 目标：定义 Deck Master 作为独立开源产品时的 Skill 体系，区分 Core Skills、Product Capability Skills 和 Reference Packs，为 v0.9.13+ 的 packaging / migration / setup 设计提供前置依据。
- `deck-master-v1.0-skill-suite-interaction-spec.md`
  - 目标：参考 GStack 的多 skill 体系，把 Deck Master v1.0 Skill Suite 设计成用户输入驱动的完整工作流，明确 `deck-*` 主入口、`ppt-*` 兼容别名、Workspace 初始化、连续 workflow、setup / upgrade / doctor、路由表和验收标准。
- `skill-os-runtime-v1.1/`
  - 目标：把 Deck Master v1.1 升级为具备阶段契约、交接、审批、自动推进和可视化状态的 Skill OS Runtime。
  - 当前入口：`skill-os-runtime-v1.1/README.md`、`skill-os-runtime-v1.1/00-master-spec.md`、`skill-os-runtime-v1.1/iteration-plan.json`。
  - 本地补充：`skill-os-runtime-v1.1/LOCAL_ADOPTION.md` 和 `skill-os-runtime-v1.1/acceptance/decision-traceability.md`。
- `deck-master-v1.3.0-production-closure-spec.md`
  - 目标：把 `ppt-master` 外部生产后端、`ppt-deck-pro-max` bridge、真实 benchmark 和 RC gate 收成可验证的生产闭环。
  - 当前入口：`deck-master-v1.3.0-production-closure-spec.md`。
- `production-closure-v1.3.0/`
  - 目标：把 v1.3.0 Production Closure Spec 拆成可执行开发包。
  - 当前入口：`production-closure-v1.3.0/00-development-package.md`、`production-closure-v1.3.0/README.md`、`production-closure-v1.3.0/implementation/`、`production-closure-v1.3.0/tasks/`。
- `open-source-maturity-v1.0/`
  - 目标：把 2026-07-06 开源成熟度计划拆成可执行开发包，先达成 M1 public Technical Preview，再推进 M2 正式开源 RC。
  - 当前入口：`open-source-maturity-v1.0/README.md`、`open-source-maturity-v1.0/00-master-spec.md`、`open-source-maturity-v1.0/tasks/`、`open-source-maturity-v1.0/acceptance/`。
- `deck-master-ppt-library-bridge-runtime-closure-spec-v1.md`
  - 目标：固定 release-local Python 3.12，补齐 PPT Library per-beat bridge、零标注语义降级、路径脱敏、跨页去重、Sourcing v2 单一真相源和多维 readiness。
  - 边界：Deck Master 主责实现；PPT Library 代码和本机数据库仅做独立只读验证，不在本 Spec 中修改。
  - 基线：正式发布基线为 `main@cc5b112`；开发目标基线为 `chore/1.0.0-rc-governance-ci-tier@ed2bc42`。
  - 状态：当前 active closure spec；完成后再进入 v1.0.0 RC 真实 benchmark 放行。
- `deck-master-high-density-builder-next-iteration-spec.md`
  - 目标：把 CyberPPT、native-svg-redraw、PPT Master、image-to-code 和 officecli 的可迁移能力串成 Deck Master 下一轮高密度 Builder 迭代 Spec，作为后续 GStack 评审和工程拆包输入。
- `deck-master-high-density-builder-engineering-spec-v1.md`
  - 状态：历史基线，已被 High-density Builder Core Engineering Spec v2 替代。
  - 历史目标：锁定独立 Skill、Agent-managed runtime 和首版合同外壳。
- `deck-master-high-density-builder-core-engineering-spec-v2.md`
  - 状态：当前 active development spec。
  - 目标：重新实现 MBB 内容增强、内容驱动 ImageGen、图片到原生 SVG、真实视觉 QA、SVG-to-DrawingML PPTX 和 73 页外部 benchmark，并以 20 项反伪实现探针作为核心验收门。
- `overdefense-governance-v1/`
  - 状态：当前治理迭代 Spec。
  - 目标：把 2026-09-01 审查出的 19 个活跃过度防御问题和 1 个历史残留，拆成 P0/P1/P2 可执行治理包，确保 PPT 生产链不再被不存在的密钥、不可操作审批、正常业务词误杀、历史报告永久 veto 和角色盲门禁卡死。
- `deck-master-high-density-builder-reference-migration-evidence.md`
  - 目标：记录 CyberPPT、native-svg-redraw、Product Design `image-to-code`、PPT Master 和 OfficeCLI 的参考证据、迁移行为、重写落点与冲突裁决。

`v0.9.11` 本轮补齐点：

- 真实生产链路先走 `setup-status / setup / bind-workspace / run-state`，再进入 `start-conversation` 等编排命令。
- benchmark 报表分成常规 `benchmark-report` 与 RC 用 `benchmark-rc-report`。
- fixture benchmark 案例在创建时走 `run_mode=fixture`，不会被纳入 v1.0 RC 判断。
- 文档优先说明 Deck Master 为顶层运行时，外部工具产物统一回写。

发布说明：

- `docs/2026-06-16-v0.9.11-wave2-release-note.md`

推荐落库路径：

```text
docs/specs/README.md
docs/specs/deck-master-v0.9.5-review-cockpit-frontend-spec.md
docs/specs/deck-master-v0.9.6-companion-tool-uat-spec.md
docs/specs/deck-master-v0.9.7-benchmark-harness-spec.md
docs/specs/deck-master-v0.9.9-installation-chain-hardening-spec.md
docs/specs/deck-master-v0.9.10-first-run-orchestration-enforcement-spec.md
docs/specs/deck-master-v0.9.11-orchestration-runtime-realignment-spec.md
docs/specs/deck-master-v0.9.12-skill-suite-routing-spec.md
docs/specs/deck-master-skill-system-product-architecture.md
docs/specs/deck-master-v1.0-skill-suite-interaction-spec.md
docs/specs/deck-master-v1.3.0-production-closure-spec.md
docs/specs/production-closure-v1.3.0/00-development-package.md
docs/specs/production-closure-v1.3.0/README.md
docs/specs/production-closure-v1.3.0/implementation/development-plan.md
docs/specs/production-closure-v1.3.0/implementation/P1-ppt-master-backend-certification-implementation.md
docs/specs/production-closure-v1.3.0/implementation/P2-deck-master-backend-binding-and-lock-implementation.md
docs/specs/production-closure-v1.3.0/implementation/P3-ppt-deck-pro-max-bridge-lock-and-smoke-implementation.md
docs/specs/production-closure-v1.3.0/implementation/P4-real-benchmark-execution-closure-implementation.md
docs/specs/production-closure-v1.3.0/implementation/P5-rc-gate-dogfood-release-closure-implementation.md
docs/specs/open-source-maturity-v1.0/README.md
docs/specs/open-source-maturity-v1.0/00-master-spec.md
docs/specs/open-source-maturity-v1.0/tasks/T1-release-governance.md
docs/specs/open-source-maturity-v1.0/tasks/T2-packaging-ci.md
docs/specs/open-source-maturity-v1.0/tasks/T3-backend-truth-preview-gate.md
docs/specs/open-source-maturity-v1.0/tasks/T4-docs-first-run-demo.md
docs/specs/open-source-maturity-v1.0/tasks/T5-public-fixture-seed.md
docs/specs/open-source-maturity-v1.0/tasks/T6-repo-hygiene-release-tree.md
docs/specs/open-source-maturity-v1.0/tasks/T7-review-desk-design-minimum.md
docs/specs/open-source-maturity-v1.0/tasks/T8-m2-rc-hardening.md
docs/specs/deck-master-ppt-library-bridge-runtime-closure-spec-v1.md
docs/specs/deck-master-high-density-builder-next-iteration-spec.md
docs/specs/deck-master-high-density-builder-engineering-spec-v1.md
docs/specs/overdefense-governance-v1/README.md
docs/specs/overdefense-governance-v1/00-master-spec.md
docs/specs/overdefense-governance-v1/implementation/development-plan.md
docs/specs/overdefense-governance-v1/acceptance/acceptance-matrix.md
docs/specs/skill-os-runtime-v1.1/README.md
docs/specs/skill-os-runtime-v1.1/LOCAL_ADOPTION.md
docs/specs/skill-os-runtime-v1.1/acceptance/decision-traceability.md
docs/deck-master-v0.9.12-stack-spec-pack/README.md
docs/deck-master-v0.9.12-stack-spec-pack/deck-master-v0.9.12-master-stack-breakdown.md
docs/deck-master-v0.9.12-stack-spec-pack/deck-master-v0.9.12a-suite-runtime-foundation-spec.md
docs/deck-master-v0.9.12-stack-spec-pack/deck-master-v0.9.12b-companion-workflow-contracts-spec.md
docs/deck-master-v0.9.12-stack-spec-pack/deck-master-v0.9.12c-production-closure-governance-spec.md
```

推荐开发顺序：

```text
v0.9.5 Review Cockpit Frontend
→ v0.9.6 Companion Tool UAT
→ v0.9.7 Benchmark Harness
→ v0.9.9 Installation Chain Hardening
→ v0.9.10 First-Run Setup + Orchestration Enforcement
→ v0.9.11 Orchestration Runtime Realignment
→ v0.9.12 Skill Suite Runtime Foundation Stack A/B/C
→ v1.0 Skill Suite Interaction + Workspace Workflow
→ v1.1 Skill OS Runtime Stack A/B/C
→ v1.3.0 Production Closure
→ Open Source Maturity M1 Technical Preview / M2 RC
→ PPT Library Bridge & Runtime Closure v1
→ High-Density Builder Next Iteration Spec
→ High-Density Builder Engineering Spec v1
→ Overdefense Governance v1
→ v1.0.0 RC Real Benchmark Runs
```
