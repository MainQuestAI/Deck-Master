# v0.9.16 RC Checklist

## Code & Contract

- [ ] A0–A5 完成
- [ ] B1–B5 完成
- [ ] C1–C5 完成
- [ ] 所有 canonical schema 已提交
- [ ] spec deviation 已关闭或明确接受
- [ ] 全量测试通过
- [ ] git diff check clean

## Production Truth

- [ ] Production placeholder = 0
- [ ] Fake extension failure matrix 全部阻断
- [ ] Required artifact parse = 100%
- [ ] Source fingerprint stale test 通过
- [ ] run/session binding = 100%
- [ ] final page count = 100%

## Delivery

- [ ] HTML 可打开
- [ ] PDF 可打开
- [ ] 每页 PNG 可打开
- [ ] PPTX 可打开
- [ ] PPTX editability 已声明
- [ ] Artifact manifest 完整
- [ ] Lineage 完整
- [ ] Final readiness ready
- [ ] Export package hash 已记录

## Release

- [ ] Release tree 自包含
- [ ] 原仓移动后 CLI 可用
- [ ] Clean install
- [ ] Upgrade from 0.9.13
- [ ] Rollback
- [ ] Codex targets ready
- [ ] Claude Code targets ready
- [ ] Release archive
- [ ] SHA256SUMS
- [ ] Capability lock
- [ ] `rc-gate --tier ci` 在 fresh clone / release tree 无本机 PPT Library 时通过
- [ ] Bridge v2、Sourcing v2、Library Status v2 required checks 通过
- [ ] Production / benchmark fixture policy required check 通过
- [ ] `rc-gate --tier full` 使用只读真实 UAT 副本通过
- [ ] UAT 副本位于系统 temp 根下，路径链无软链接且不指向持久 runs
- [ ] 真实 selection v2 与 sourcing v2 artifacts 通过 identity、去重与安全扫描
- [ ] UAT JSON/Markdown 只包含哈希化 run reference
- [ ] Full-tier UAT status 和所有 phase 均为 pass
- [ ] RC JSON/Markdown evidence safety scan 通过

## Real Benchmark

- [ ] ≥3 real cases
- [ ] median first-pass acceptance ≥65%
- [ ] each case acceptance ≥50%
- [ ] review-ready ratio ≤60%
- [ ] client-visible P0 = 0
- [ ] artifact validity = 100%
- [ ] private source scan clean
- [ ] human review evidence complete

## Documentation

- [ ] Quick Start 与 CLI 一致
- [ ] Agent playbook 与实际路径一致
- [ ] Migration guide
- [ ] Troubleshooting
- [ ] Known limitations
- [ ] Release notes
- [ ] 不宣称 flat-image fully editable

只有全部勾选后，才能写：`v0.9.16 is an RC candidate`。
